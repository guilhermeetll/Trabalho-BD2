--
-- PostgreSQL database cluster dump
--

\restrict 6hU3yySuDTNSJEhAFPaXTEJHaIqXR3QzOs6rwaESM7RV0JbX7sZpIUUdH7hZwyY

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE admin_user;
ALTER ROLE admin_user WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:B9ft096F75gOLAHkdJtf3w==$vZhj1EQ92o4y3Ffj4YRu9DG+RX4pE6G9VaK2LyJQXAs=:ugWPT9bMkhUoYwWnVjmM6PcGHno8I8GhvkcQFDRsc5I=';
CREATE ROLE funcionario_user;
ALTER ROLE funcionario_user WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:K00e3nE6GR8AFHO/ylYtwA==$EN87hdMFoemEXlngeZKRbfCoFSGgN7TXQzBtnhaDkwE=:tk1FhuT/TnVdedYUH74YWq5hVq54XospKHJN7mY9lcE=';
CREATE ROLE loja_app;
ALTER ROLE loja_app WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:kCFn0LJihfLnMEGE9aqBmA==$HS9SITnZw088t2dzoAcQi/OuQjkfR0n/nNOFpO14REc=:46Ipzb0zH52iZfgKcux4jaKSQZOTlSKk1cCg/Qnjq9E=';
CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:lifEcfnPFGHETaQKnDEnGQ==$aiXg+3KwUVgbFYvFWwdIKmgdflqO2tJVr0g7MeTUnFo=:gY3B5uO9EDG4Egstrl8dQ5I0+9lWuzVPjrc+8HHPKhg=';
CREATE ROLE role_admin;
ALTER ROLE role_admin WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB NOLOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE role_funcionario;
ALTER ROLE role_funcionario WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB NOLOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE role_visitante;
ALTER ROLE role_visitante WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB NOLOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE visitante_user;
ALTER ROLE visitante_user WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:t9WcDhK9JnwTyuSG6JN5Wg==$UJLoncJOrPjizpPRWyjLTLa0r2Tgz1uFwtX8C7NhPFU=:b9JixOBA79jGt3MtqUYwuLlxqfJ/77LvW1fnphY/YAM=';

--
-- User Configurations
--


--
-- Role memberships
--

GRANT role_admin TO admin_user WITH INHERIT TRUE GRANTED BY postgres;
GRANT role_funcionario TO funcionario_user WITH INHERIT TRUE GRANTED BY postgres;
GRANT role_visitante TO visitante_user WITH INHERIT TRUE GRANTED BY postgres;






\unrestrict 6hU3yySuDTNSJEhAFPaXTEJHaIqXR3QzOs6rwaESM7RV0JbX7sZpIUUdH7hZwyY

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict opNypVX5cA32Qa3WK2V8vfhxB30JfGTZjeScAK036WIOalBJR0BnciQe8RpRY6f

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict opNypVX5cA32Qa3WK2V8vfhxB30JfGTZjeScAK036WIOalBJR0BnciQe8RpRY6f

--
-- Database "lojavirtual" dump
--

--
-- PostgreSQL database dump
--

\restrict jpKH3O7aWeqoNlzLec9kQ71tHh8lBPJaLXxA1o31HAy7OyHB9ZnitpYHsOA0maU

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: lojavirtual; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE lojavirtual WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE lojavirtual OWNER TO postgres;

\unrestrict jpKH3O7aWeqoNlzLec9kQ71tHh8lBPJaLXxA1o31HAy7OyHB9ZnitpYHsOA0maU
\connect lojavirtual
\restrict jpKH3O7aWeqoNlzLec9kQ71tHh8lBPJaLXxA1o31HAy7OyHB9ZnitpYHsOA0maU

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict jpKH3O7aWeqoNlzLec9kQ71tHh8lBPJaLXxA1o31HAy7OyHB9ZnitpYHsOA0maU

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict 99dO5kvGThV3bK55e85TcAiOrqZ3Wawy57Xll6NUJYYb6FpAcRgTyqgbBDeldkH

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 99dO5kvGThV3bK55e85TcAiOrqZ3Wawy57Xll6NUJYYb6FpAcRgTyqgbBDeldkH

--
-- PostgreSQL database cluster dump complete
--

